/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.tue;

import gr.spinellis.ckjm.ClassMetricsContainer;
import gr.spinellis.ckjm.MetricsFilter;
import gr.spinellis.ckjm.ant.PrintCsvResults;
import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 *
 * @author econst
 */
public class Main {
    private static final String originalClassPath = System.getProperty("java.class.path");
    
    private static List<String> getFileNames(List<String> fileNames, Path dir) {
        try(DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path path : stream) {
                if(path.toFile().isDirectory()) {
                    getFileNames(fileNames, path);
                } else {
                    if (path.toAbsolutePath().toString().endsWith(".class")){
                        fileNames.add(path.toAbsolutePath().toString());
                    }

                }
            }
        } catch(IOException e) {
            e.printStackTrace();
        }
        return fileNames;
    }
    
    private static void extractClassesInJar(String jarName,String outputdir) throws IOException {
    	UnzipUtility uu = new UnzipUtility();
    	uu.unzip(jarName, outputdir);
    }
    
    private static void extendClassPath(String jarName,List<String> depJarsFiles) {
        String finalClasspath = originalClassPath;
        finalClasspath += File.pathSeparator;
        finalClasspath += jarName;
        if (depJarsFiles != null
                && depJarsFiles.size() > 0) {
            for (int j = 0; j < depJarsFiles.size(); j++) {
                finalClasspath += File.pathSeparator;
                finalClasspath += depJarsFiles.get(j);
            }
        }

        try {

            for (int j = 0; j < depJarsFiles.size(); j++) {
                //System.out.println(depJarsFiles[j]);
                ZipFile zf = new ZipFile(depJarsFiles.get(j));
                Enumeration e = zf.entries();
                while (e.hasMoreElements()) {
                    ZipEntry ze = (ZipEntry) e.nextElement();
                    if (ze.getName().endsWith(".class")) {
                        finalClasspath += File.pathSeparator;
                        //If run in Windows, change / in path to \
                        if (System.getProperty("os.name").contains("Windows")) {
                            finalClasspath += Paths.get(depJarsFiles.get(j)).getParent().toString() + "\\" + ze.getName().replace("/", "\\");
                        } else {
                            finalClasspath += Paths.get(depJarsFiles.get(j)).getParent().toString() + "/" + ze.getName();
                        }
                    }
                }
                zf.close();
            }

            System.setProperty("java.class.path", finalClasspath);
        } catch (Exception ee) {
            ee.printStackTrace();
            System.out.println("Error setting classpath");
        }

    }
    
    public static void main(String[] argv) {
        String jarName = argv[0];
        String librariesJarFolder = argv[1];
        
        String classesLocation = jarName.substring(0, jarName.indexOf(".jar"));
        
        
        try{
        	extractClassesInJar(jarName,classesLocation);
            
            List<String> depsJars = new ArrayList<>();
            depsJars = getFileNames(depsJars,Paths.get(librariesJarFolder));
            
            ClassMetricsContainer cm = new ClassMetricsContainer();

            extendClassPath(jarName,depsJars);
            
            List<String> classNames = new ArrayList<>();
            classNames = getFileNames(classNames,Paths.get(classesLocation));
            for (int i=0;i<classNames.size();i++){
                MetricsFilter.processClass(cm, classNames.get(i));
            }
            
          //CkjmOutputHandler handler = new PrintCsvResults(System.out);
            PrintCsvResults handler = new PrintCsvResults(System.out);
            
            handler.printHeader();
            cm.printMetrics(handler);
        }catch(Exception ee){
            ee.printStackTrace();
        }

        

        
        System.setProperty("java.class.path", originalClassPath);
    }
}
