/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.spinellis.ckjm.ant;

/**
 *
 * @author econst
 */
import gr.spinellis.ckjm.CkjmOutputHandler;
import gr.spinellis.ckjm.ClassMetrics;

import java.io.PrintStream;

/**
 * XML output formatter
 *
 * @author Julien Rentrop
 */
public class PrintCsvResults implements CkjmOutputHandler {
    private PrintStream p;

    public PrintCsvResults(PrintStream p) {
        this.p = p;
    }

    public void printHeader() {
        p.println("ClassName,WMC,DIT,NOC,CBO,RFC,LCOM,CA,NPM");
    }

    public void handleClass(String name, ClassMetrics c) {
        p.print(name+","+c.getWmc()+","+c.getDit()+","+c.getNoc()+","+c.getCbo()+","+c.getRfc()+","+c.getLcom()+","+c.getCa()+","+c.getNpm()+"\n");
    }
}

